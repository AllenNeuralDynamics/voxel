# Copyright Euresys 2020

"""Helper functions to build Euresys GenApi actions."""

from .generated import cEGrabber as cE
from . import utils
import ctypes as ct

def _handler(func):
    with utils.Ctype(cE.Eur_action_GenApiActionBuilder) as builder:
        func(ct.byref(builder.box))
        with utils.Ctype.std_string() as action:
            cE.Eur_action_GenApiActionBuilder_string(builder.box, ct.byref(action.box))
            return action.box_value

def declare_integer():
    """Create an action to declare a virtual user feature of type Integer on a GenApi Module.

    Returns
    -------
    str
    """
    return _handler(cE.Eur_action_declareInteger)

def declare_float():
    """Create an action to declare a virtual user feature of type Float on a GenApi Module.

    Returns
    -------
    str
    """
    return _handler(cE.Eur_action_declareFloat)

def declare_string():
    """Create an action to declare a virtual user feature of type String on a GenApi Module.

    Returns
    -------
    str
    """
    return _handler(cE.Eur_action_declareString)

def undeclare():
    """Create an action to undeclare (delete) a virtual user feature on a GenApi Module.

    Returns
    -------
    str
    """
    return _handler(cE.Eur_action_undeclare)
