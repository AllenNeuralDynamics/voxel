# -*- coding: utf-8 -*-
from ._connections import Board as _Board, Channel as _Channel
from .registers import icc_registers as Registers
from .registers.icc_registers import ICCStaticInput
from .tools.list_comports import get_icc4c_port

"""ECC-1c SDK.

The ECC-1c SDK is organized in the following way:

         Board.Channel.System.RegisterCommand(parameters)

  Board:      Low/mid level object for operating the firmware (vector patterns, simple/pro commands, etc)
  Channel:    A given channel, which can set input types, gain, etc.
  System:     Each channel has its own stages. From here can perform commands that get/set individual registers.
  registers:  Each system has several registers, which are dictionaries with elements regarding valid units/range.


To begin:
Import necessary module and initialize a board (verbose for console output)

>>>import optoICC
>>>ecc = optoICC.connectEcc(port='COM12')  # this will connect and synchronize all channel with the firmware

Define the system you want to interact with (board.mirror.channel.system) (see registers.system_names for a list)
>>>sig_gen = ecc.SignalGenerator
Start setting individual registers
>>>sig_gen.SetAmplitude(0.1)

Additional operations are available directly through the Board object (get/set multiple, reset, etc)
For example, multiple set/get can be done. After this, the system will output a sinusoid on channel 0.
>>>ecc.set_value([sig_gen.frequency, sig_gen.amplitude, sig_gen.unit, sig_gen.run], [10.0, 0.1, Units.CURRENT, 1])
>>>ecc.get_value([sig_gen.frequency, sig_gen.amplitude, sig_gen.unit, sig_gen.run])

Example
-------
More examples to come...
"""


# standard ECC-1c Board
class ECC1cBoard(_Board):
    def __init__(self, port: str or None = None, baudrate: int = 256000, comm_lock: bool = True,
                 verbose: bool = False, simple: bool = False,
                 board_reset: bool = False, inter_byte_timeout: float = 0.2):
        if port is None:
            try:
                port = get_icc4c_port()
            except IndexError:
                print("ICC-4c Device Not Found. Check Connection.")
        _Board.__init__(self, port=port, baudrate=baudrate, comm_lock=comm_lock,
                        verbose=verbose, simple=simple,
                        board_reset=board_reset, inter_byte_timeout=inter_byte_timeout)
        # board-level systems
        ## => \link optoICC.registers.icc_registers.ICCStatus ICCStatus\endlink
        self.Status = Registers.ICCStatus(board=self)
        ## => \link optoKummenberg.registers.MiscSystems.VectorPatternMemory VectorPatternMemory\endlink
        self.VectorPatternMemory = Registers.VectorPatternMemory(board=self)
        ## => \link optoICC.registers.icc_registers.ICCTemperatureManager ICCTemperatureManager\endlink
        self.TemperatureManager = Registers.ICCTemperatureManager(board=self)
        ## => \link optoICC.registers.icc_registers.ICCMiscFeatures ICCMiscFeatures\endlink
        self.MiscFeatures = Registers.ICCMiscFeatures(board=self)
        ## => \link optoKummenberg.registers.MiscSystems.Logger Logger\endlink
        self.Logger = Registers.Logger(board=self)
        ## => \link optoICC.registers.icc_registers.ICCBoardEEPROM ICCBoardEEPROM\endlink
        self.EEPROM = Registers.ICCBoardEEPROM(board=self)
        ## => \link optoKummenberg.registers.MiscSystems.SnapshotManager SnapshotManager\endlink
        self.SnapshotManager = Registers.SnapshotManager(board=self)
        ## => \link optoICC.ecc1c.ECC1cChannel ECC1cChannel\endlink
        self.Lens = ECC1cChannel(self, 0)
        self.channel = [self.Lens]

        if self.verbose:
            print('Initialization Finalized. Board is Ready.')


class ECC1cChannel(_Channel):
    def __init__(self, board, channel_number: int = 0):
        _Channel.__init__(self, board, channel_number)

        ## => \link optoICC.registers.icc_registers.ICCStaticInput ICCStaticInput\endlink
        self.StaticInput = ICCStaticInput(self._channel, self._board)
        ## => \link optoKummenberg.registers.InputStage.Analog Analog\endlink
        self.Analog = Registers.Analog(self._channel, self._board)
        ## => \link optoICC.registers.icc_registers.LensCompensation LensCompensation\endlink
        self.LensCompensation = Registers.LensCompensation(self._channel, self._board)
        ## => \link optoKummenberg.registers.InputStage.SignalGenerator SignalGenerator\endlink
        self.SignalGenerator = Registers.ICCSignalGenerator(self._channel, self._board)
        ## => \link optoICC.registers.icc_registers.DeviceEEPROM DeviceEEPROM\endlink
        self.DeviceEEPROM = Registers.DeviceEEPROM(self._channel, self._board)
        ## => \link optoKummenberg.registers.InputStage.VectorPatternUnit VectorPatternUnit\endlink
        self.VectorPatternUnit = Registers.VectorPatternUnit(self._channel, self._board)
        ## => \link optoICC.registers.icc_registers.ICCDeviceTemperatureManager ICCDeviceTemperatureManager\endlink
        self.TemperatureManager = Registers.ICCDeviceTemperatureManager(self._channel, self._board)
        ## => \link optoKummenberg.registers.OutputConditioning.OutputConditioningFilter OutputConditioningFilter\endlink
        self.OutputConditioningFilter = Registers.OutputConditioningFilter(self._channel, self._board)

